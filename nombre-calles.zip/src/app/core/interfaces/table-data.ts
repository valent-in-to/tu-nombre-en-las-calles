export interface TableData {
    tipo 
    nombre
    departamento
    localidad
    provincia    
}
